gcc -no-pie -c a.c -o a.o
as c.asm -o c.o

gcc -no-pie a.c c.o -o my_test.out

./prf doesnt_exist my_test.out 1 2 3 $'first run\n' 1> temp_output.txt 2> temp_err.txt
./prf inner1 my_test.out 1 2 3 $'second run\n' 1>> temp_output.txt 2>>temp_err.txt
./prf target_function my_test.out 1 2 3 $'third run\n' 1>> temp_output.txt 2>>temp_err.txt
./prf my_exit my_test.out 1 2 3 $'fourth run\n' 1>> temp_output.txt 2>>temp_err.txt
diff temp_output.txt expected_output.txt
diff temp_err.txt expected_err.txt
