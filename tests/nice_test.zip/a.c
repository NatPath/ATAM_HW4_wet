#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

void jj(const char* what_to_print, size_t its_length);

void my_exit();
static void target_function() {
	return;
}

int main(int argc, char* argv[]) {
	if (argc != 5) {
		printf("Arguments weren't passed correctly.\n");
		return 1;
	}
	target_function();
	jj(argv[4], strlen(argv[4]));
	my_exit();
}

